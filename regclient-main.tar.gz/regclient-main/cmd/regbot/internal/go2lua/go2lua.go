// Package go2lua converts between go and Lua data structures
package go2lua

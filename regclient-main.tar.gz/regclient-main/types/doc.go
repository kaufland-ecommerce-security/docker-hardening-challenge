// Package types defines various types that have no other internal imports
// This allows them to be used between other packages without creating import loops
package types

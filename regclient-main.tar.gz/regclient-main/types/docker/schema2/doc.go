// Package schema2 contains structs for Docker schema v2 manifests.
package schema2

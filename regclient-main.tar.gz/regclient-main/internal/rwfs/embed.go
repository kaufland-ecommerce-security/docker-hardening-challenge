package rwfs

// implement rwfs on top of an embed FS
// TODO: extend embed.FS with a copy-on-write for files (and recursively on directories)

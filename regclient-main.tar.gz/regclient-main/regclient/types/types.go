//go:build !nolegacy
// +build !nolegacy

// Package types is a legacy package, using the top level types package is recommended
package types
